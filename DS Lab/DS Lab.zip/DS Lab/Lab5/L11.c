#include <stdio.h>

#define MAX 100

char stack[MAX];
int top = -1;

void push(char x) {
    stack[++top] = x;
}

char pop() {
    return stack[top--];
}

int precedence(char x) {
    if (x == '+' || x == '-')
        return 1;
    else if (x == '*' || x == '/')
        return 2;
    else if (x == '^')
        return 3;
    return 0;
}

// Custom function to calculate string length
int string_length(char str[]) {
    int length = 0;
    while (str[length] != '\0') {
        length++;
    }
    return length;
}

void infix_to_postfix(char infix[], char postfix[]) {
    int i, j = 0;
    for (i = 0; infix[i] != '\0'; i++) {
        if ((infix[i] >= 'a' && infix[i] <= 'z') || (infix[i] >= 'A' && infix[i] <= 'Z')) {
            postfix[j++] = infix[i];
        }
        else if (infix[i] == '(') {
            push(infix[i]);
        }
        else if (infix[i] == ')') {
            while (stack[top] != '(') {
                postfix[j++] = pop();
            }
            pop();  // Remove '('
        } 
        else {
            while (top != -1 && stack[top] != '(' && precedence(stack[top]) >= precedence(infix[i])) {
                postfix[j++] = pop();
            }
            push(infix[i]);
        }
    }
    while (top != -1) {
        postfix[j++] = pop();
    }
    postfix[j] = '\0';
}

void infix_to_prefix(char infix[], char prefix[]) {
    int n = 0;
    while (infix[n] != '\0') {
        push(infix[n]);
        n++;
    }
    n = 0;
    while (top != -1) {
        infix[n] = pop();
        n++;
    }
    
    int i, j = 0;
    for (i = 0; infix[i] != '\0'; i++) {
        if ((infix[i] >= 'a' && infix[i] <= 'z') || (infix[i] >= 'A' && infix[i] <= 'Z')) {
            prefix[j++] = infix[i];
        }
        else if (infix[i] == '(') {
            push(infix[i]);
        }
        else if (infix[i] == ')') {
            while (stack[top] != '(') {
                prefix[j++] = pop();
            }
            pop();  // Remove '('
        } 
        else {
            while (top != -1 && stack[top] != '(' && precedence(stack[top]) >= precedence(infix[i])) {
                prefix[j++] = pop();
            }
            push(infix[i]);
        }
    }
    while (top != -1) {
        prefix[j++] = pop();
    }
    prefix[j] = '\0';
}

int main() {
    char infix[MAX], postfix[MAX], prefix[MAX];
    
    printf("Enter an infix expression: ");
    fgets(infix, MAX, stdin);  // Use fgets instead of gets for safer input handling

    // Remove the newline character if present
    int len = string_length(infix);
    if (infix[len - 1] == '\n') {
        infix[len - 1] = '\0';
    }

    infix_to_postfix(infix, postfix);
    printf("Postfix expression: %s\n", postfix);

    infix_to_prefix(infix, prefix);
    printf("Prefix expression: %s\n", prefix);

    return 0;
}
