#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX 100

// Define the Stack structure
typedef struct {
    char data[MAX];
    int top;
} Stack;

// Initialize the stack
void initStack(Stack *s) {
    s->top = -1;
}

// Check if the stack is empty
int isEmpty(Stack *s) {
    return s->top == -1;
}

// Push a character onto the stack
void push(Stack *s, char c) {
    if (s->top < MAX - 1) {
        s->top++;
        s->data[s->top] = c;
    }
}

// Pop a character from the stack
char pop(Stack *s) {
    if (!isEmpty(s)) {
        return s->data[s->top--];
    }
    return '\0';
}

// Function to check if a string is a palindrome
int isPalindrome(char str[]) {
    Stack s;
    initStack(&s);

    int len = strlen(str);
    for(int i=0;str[i]!='\0';i++){
        push(&s,str[i]);
    }
    for(int i=0;str[i]!='\0';i++){
        if(str[i]!=pop(&s)) return 0;
    }

    return 1;  // It's a palindrome
}

int main() {
    char str[MAX];
    printf("Enter a string: ");
    gets(str);  // Use fgets in modern C for better safety

    if (isPalindrome(str)) {
        printf("The string is a palindrome.\n");
    } else {
        printf("The string is not a palindrome.\n");
    }

    return 0;
}
